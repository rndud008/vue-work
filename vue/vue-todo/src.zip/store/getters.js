export const storedTodoItems = (state) =>{
  return state.todoItems;
}