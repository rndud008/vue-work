<template>
    <header>
        <h1>TODO it!</h1>
        <!-- <h1>{{this.$store.state.headerText}}</h1> -->
    </header>
</template>

<style scoped>
/*  scoped 는 해당 컴포넌트에서만 존재 */
h1{
    color: #2f3b52;
    font-weight: 900;
    margin: 2.5rem 0 1.5rem;
}

</style>